package com.avesta.avesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvestaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvestaApplication.class, args);
	}

}
