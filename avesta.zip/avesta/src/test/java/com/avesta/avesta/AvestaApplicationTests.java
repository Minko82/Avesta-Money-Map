package com.avesta.avesta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvestaApplicationTests {

	@Test
	void contextLoads() {
	}

}
